import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule, NgForm } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../services/data.service'; // ✅ adapte le chemin si besoin

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
  ],
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css'],
})
export class RegisterComponent implements OnInit {

  constructor(private authService: AuthService) {} // ✅ injection du service

  ngOnInit(): void {
    // initialisation si besoin
  }

  user: any = {};
  selectedPhonePrefix = '+216';  // Définir le préfixe du téléphone
  showAssociationField = false;  // Champ d'association à afficher ou non
  successMessage: string | null = null;
  maxBirthDate = new Date().toISOString().split('T')[0];  // Limite de la date de naissance à aujourd'hui

  // Fonction pour afficher ou masquer le champ 'association'
  toggleAssociationField() {
    this.showAssociationField = this.user.typeAmbassadeur === 'ASSOCIATION';
    if (!this.showAssociationField) {
      this.user.association = null;  // Réinitialiser le champ 'association' si le type d'ambassadeur n'est pas 'ASSOCIATION'
    }
  }

  // Fonction appelée lors de la soumission du formulaire
  onSubmit(form: NgForm) {
    if (form.valid) {
      // Associer le préfixe téléphonique
      this.user.phone = this.selectedPhonePrefix + this.user.phone.replace(this.selectedPhonePrefix, '');

      // Créer l'objet JSON à envoyer au backend
      const requestBody = {
        firstName: this.user.firstName,
        lastName: this.user.lastName,
        email: this.user.email,
        password: this.user.password,
        confirmPassword: this.user.confirmPassword,
        phone: this.user.phone,
        cin: this.user.cin,
        birthDate: this.user.birthDate,  // Assurez-vous que la date est au format correct (ex: '1990-01-01')
        country: this.user.country,
        userType: this.user.userType,
        typeAmbassadeur: this.user.typeAmbassadeur,
        association: this.user.association,
        gouvernorat: this.user.gouvernorat
      };

      // Appel au service pour l'enregistrement
      this.authService.register(requestBody).subscribe({
        next: (response) => {
          console.log('Inscription réussie:', response);
          this.successMessage = `Votre demande d'inscription a été envoyée avec succès !`;
          form.resetForm();  // Réinitialiser le formulaire après soumission
          this.user = {};  // Réinitialiser les données utilisateur
          this.selectedPhonePrefix = '+216';  // Réinitialiser le préfixe du téléphone
        },
        error: (error) => {
          console.error('Erreur lors de l\'inscription:', error);
        }
      });
    }
  }
}
