import { Component } from '@angular/core';

@Component({
  selector: 'app-parrainage',
  imports: [],
  templateUrl: './parrainage.component.html',
  styleUrl: './parrainage.component.css'
})
export class ParrainageComponent {

}
