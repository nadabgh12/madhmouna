import { Component } from '@angular/core';

@Component({
  selector: 'app-ambassadeur',
  standalone: true,
  templateUrl: './ambassadeur.component.html',
  styleUrls: ['./ambassadeur.component.scss']
})
export class AccountComponent {}