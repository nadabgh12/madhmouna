import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { AuthService } from '../services/data.service'; // chemin à adapter

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  email = '';
  password = '';
  showLogin: any;

  constructor(private dataService: AuthService) {}

  login() {
    console.log('Tentative de connexion avec', this.email, this.password);
    this.dataService.login(this.email, this.password).subscribe({
      next: (response) => {
        console.log('Connexion réussie', response);
        // redirection ou stockage du token si nécessaire
      },
      error: (error) => {
        console.error('Erreur de connexion', error);
      }
    });
  }

  toggleView() {
    // à implémenter si tu gères plusieurs vues
  }
}
